# Run this quotation app 24/7 (5 minutes)

The app is a normal Next.js + PostgreSQL project. The sandbox it lives in now
stops when the session ends, so for a permanent public link you deploy it once
to a hosting platform. Two things are needed: **a hosted Postgres database**
and **a hosting platform**.

## 1. Create a free hosted database (2 min)

Pick any one:

- **Neon** — neon.tech (free tier, fastest): create project → copy the
  `Connection string` (starts with `postgresql://`).
- **Supabase** — supabase.com: create project → Database → Connection string.
- **Render** — render.com: New → PostgreSQL → copy the external URL.

The URL looks like:
`postgresql://user:password@host:5432/dbname?sslmode=require`

## 2. Deploy (choose one)

### A. Vercel (recommended — free, easiest)
1. Push this folder to a GitHub repo (the `.env` file is git-ignored — good).
2. Go to **vercel.com → Import Project** → select the repo → Deploy.
3. In Vercel: **Settings → Environment Variables** → add
   `DATABASE_URL` = your URL from step 1 → **Redeploy**.
   (Optional but recommended: also add the Neon S3 keys
   `AWS_ENDPOINT_URL_S3`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`,
   `AWS_REGION`, `S3_BUCKET` so letterhead uploads live in object storage
   instead of the database.)
4. Done — your public link is `https://your-project.vercel.app`.

### B. Render (free Postgres + hosting together)
1. Create a **Web Service** from the same GitHub repo.
   - Build command: `npm run build`
   - Start command: `npm start`
2. Create a **PostgreSQL** database on Render (free tier).
3. In the web service: **Environment → Add Env Var** →
   `DATABASE_URL` = the Render Postgres URL → deploy.

### C. Railway / Fly.io / Koyeb
Same pattern: connect the repo, set `DATABASE_URL`, deploy.

## 3. What happens automatically
- The app creates its `documents` table on first use (no migrations to run).
- Your edits and uploaded letterhead are stored in the database and survive
  restarts.
- `/api/health` returns `{"ok":true}` when the database is connected.

## Notes
- Never commit the real `.env` (already git-ignored). Keep `DATABASE_URL`
  server-side only — the app never sends it to the browser.
- Want the shortest possible link? After deploying, point a short custom
  domain (e.g. `q.yourcompany.com`) at it, or use a redirect like
  `yourdomain.com/q` → the deployment URL.
