# Import this project into a new E2B sandbox

Everything needed is in the project folder (or the ready-made bundle
`quotation-app.tar.gz`). No external assets, fonts are embedded, and the
database table creates itself on first use.

## What you need first
- A new E2B sandbox from the **`nextjs-postgres`** template (or any sandbox
  with Node 20+ and PostgreSQL).
- `DATABASE_URL` — the sandbox's Postgres connection string
  (default format: `postgresql://postgres:postgres@127.0.0.1:5432/app_db`).
  Put it in `.env` (see `.env.example`).
- (Optional) Neon S3-compatible storage keys for letterhead uploads —
  `AWS_ENDPOINT_URL_S3`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`,
  `AWS_REGION`, `S3_BUCKET`. Without them, letterheads are stored inside
  the database as images instead (still works, just heavier on the DB).

## Option A — Import the bundle (fastest)
1. Copy `quotation-app.tar.gz` into the new sandbox (upload, or
   `sandbox.files.write` / mount).
2. Extract it:
   ```bash
   tar -xzf quotation-app.tar.gz
   cd app   # or the folder it extracted into
   ```
3. Install dependencies:
   ```bash
   npm ci
   ```
4. Set the database URL (edit `.env`, or export it):
   ```bash
   echo "DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db" > .env
   ```
5. Build and run (the `documents` table is created automatically on first use — no migration needed):
   ```bash
   npm run build
   npm start        # serves on port 3000
   ```
7. Verify: `curl http://localhost:3000/api/health` → `{"ok":true}`.

## Option B — From GitHub (best for updates)
1. Push this folder to a GitHub repo (`.env` is git-ignored — safe).
2. In the new sandbox:
   ```bash
   git clone https://github.com/YOU/quotation-app.git
   cd quotation-app
   npm ci
   echo "DATABASE_URL=..." > .env
   npx drizzle-kit push --force
   npm run build && npm start
   ```

## Option C — Bake it into an E2B template (owner)
```bash
e2b template build --name quotation-app   # runs in this folder
# then create sandboxes with: template: "quotation-app"
```

## Make it public + auto-resume (owner, at creation)
```js
const sandbox = await Sandbox.create({
  template: 'quotation-app',          // or 'nextjs-postgres' + Option A/B
  timeoutMs: 60 * 60 * 1000,
  network: { allowPublicTraffic: true },
  lifecycle: { onTimeout: 'pause', autoResume: true },
})
console.log(sandbox.getHost(3000))    // public URL
```

## Notes
- A new sandbox starts with the **default sample quotation** (clean DB).
  Your previous edits/letterhead lived in the old sandbox's database —
  re-enter them here, or restore with `pg_dump`/`psql` from the old DB.
- First visit after a pause takes ~1–2 s while the sandbox wakes.
- Full hosting guide (Vercel/Render for a permanent 24/7 link): see `DEPLOY.md`.
