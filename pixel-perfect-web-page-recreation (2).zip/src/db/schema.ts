import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/** Stores each saved quotation document (one row per quotation). */
export const quotations = pgTable("quotations", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  data: jsonb("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Legacy single-document table (kept for migration of older saves). */
export const documents = pgTable("documents", {
  id: text("id").primaryKey(),
  data: jsonb("data").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
