import QuoteEditor from "@/components/quote/Editor";
import { listQuotations, loadQuotation } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function Home() {
  const { quotations, activeId } = await listQuotations();
  const { doc } = await loadQuotation(activeId);
  return <QuoteEditor initialState={{ quotations, activeId, initialDoc: doc }} />;
}
