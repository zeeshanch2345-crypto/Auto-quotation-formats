import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./fonts.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Commercial Offer – Unique Innovations Company",
  description: "Commercial offer for the supply of rental manpower – Unique Innovations Company (UIC).",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#2e3157",
};

/* Sets the page zoom before first paint so A4 sheets fit any screen width. */
const fitScript = `(function(){var d=document.documentElement;d.classList.add('js');function f(){var w=window.innerWidth||d.clientWidth||794;var mobile=w<=760;var space=mobile?w-20:w-370;var z=Math.min(1,Math.max(.2,space/794));d.style.setProperty('--page-zoom',z.toFixed(4));}f();window.addEventListener('resize',f);})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: fitScript }} />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
