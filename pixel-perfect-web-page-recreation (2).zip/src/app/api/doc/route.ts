import { loadDoc, saveDoc } from "@/lib/store";

export const dynamic = "force-dynamic";

/** Compatibility endpoint: reads/writes the most recently active quotation. */
export async function GET() {
  const { doc, updatedAt } = await loadDoc();
  return Response.json({ doc, updatedAt }, { headers: { "Cache-Control": "no-store" } });
}

async function handleSave(req: Request) {
  let body: unknown;
  try {
    const raw = await req.text();
    if (raw.length > 8_000_000) {
      return Response.json({ ok: false, error: "Document too large" }, { status: 413 });
    }
    body = JSON.parse(raw);
  } catch {
    return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }
  const payload = typeof body === "object" && body !== null && "doc" in body ? (body as { doc: unknown }).doc : body;
  try {
    const { updatedAt } = await saveDoc(payload);
    return Response.json({ ok: true, updatedAt }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    console.error("saveDoc failed", err);
    return Response.json({ ok: false, error: "Could not save" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  return handleSave(req);
}

export async function PUT(req: Request) {
  return handleSave(req);
}
