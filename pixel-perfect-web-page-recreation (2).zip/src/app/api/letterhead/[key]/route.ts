import { getLetterheadObject, isValidLetterheadKey } from "@/lib/s3";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Streams a stored letterhead page back to the browser (private bucket proxy). */
export async function GET(_req: Request, { params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  if (!isValidLetterheadKey(key)) return new Response("Not found", { status: 404 });
  const obj = await getLetterheadObject(key);
  if (!obj) return new Response("Not found", { status: 404 });
  return new Response(obj.body, {
    headers: {
      "Content-Type": obj.contentType,
      "Cache-Control": "public, max-age=31536000, immutable",
      ...(obj.length ? { "Content-Length": String(obj.length) } : {}),
    },
  });
}
