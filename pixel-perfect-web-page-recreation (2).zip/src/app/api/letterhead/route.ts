import { isLetterheadConfigured, putLetterheadObject } from "@/lib/s3";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 40 * 1024 * 1024;
const ALLOWED = new Set(["image/webp", "image/png", "image/jpeg", "image/avif"]);

/** Accepts a letterhead page image, stores it in S3-compatible storage, and
 *  returns a same-origin proxy URL (the bucket itself is private). */
export async function POST(req: Request) {
  if (!isLetterheadConfigured()) {
    return Response.json({ ok: false, error: "Cloud storage is not configured" }, { status: 503 });
  }
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ ok: false, error: "Invalid upload" }, { status: 400 });
  }
  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return Response.json({ ok: false, error: "No file received" }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return Response.json({ ok: false, error: "File is too large (max 40 MB)" }, { status: 413 });
  }
  if (!ALLOWED.has(file.type)) {
    return Response.json({ ok: false, error: "Use a WebP, PNG, JPG or AVIF image" }, { status: 415 });
  }
  const ext = file.type.split("/")[1] === "jpeg" ? "jpg" : file.type.split("/")[1];
  const key = `lh-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}.${ext}`;
  try {
    await putLetterheadObject(key, Buffer.from(await file.arrayBuffer()), file.type);
  } catch (err) {
    console.error("letterhead upload failed", err);
    return Response.json({ ok: false, error: "Cloud upload failed" }, { status: 502 });
  }
  return Response.json({ ok: true, key, url: `/api/letterhead/${key}` });
}
