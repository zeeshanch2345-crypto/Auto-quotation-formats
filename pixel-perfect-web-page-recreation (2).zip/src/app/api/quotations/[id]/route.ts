import { deleteQuotation, loadQuotation, saveQuotation } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { doc, updatedAt } = await loadQuotation(id);
  return Response.json({ doc, updatedAt }, { headers: { "Cache-Control": "no-store" } });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
  }
  const payload = typeof body === "object" && body !== null && "doc" in body ? (body as { doc: unknown }).doc : body;
  try {
    const { doc, updatedAt } = await saveQuotation(id, payload);
    return Response.json({ ok: true, doc, updatedAt }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    console.error("saveQuotation failed", err);
    return Response.json({ ok: false, error: "Could not save" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    await deleteQuotation(id);
    return Response.json({ ok: true });
  } catch (err) {
    console.error("deleteQuotation failed", err);
    return Response.json({ ok: false, error: "Could not delete" }, { status: 500 });
  }
}
