import { createQuotation, listQuotations } from "@/lib/store";

export const dynamic = "force-dynamic";

/** List all saved quotations (most recently updated first) + the active one. */
export async function GET() {
  try {
    const { quotations, activeId } = await listQuotations();
    return Response.json({ quotations, activeId }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    console.error("listQuotations failed", err);
    return Response.json({ quotations: [], activeId: "", error: "Could not list quotations" }, { status: 500 });
  }
}

/** Create a quotation. Body: {} for a fresh template, or { "copyFrom": "<id>" } to duplicate. */
export async function POST(req: Request) {
  let copyFrom: string | undefined;
  try {
    const body = await req.json();
    if (body && typeof body === "object" && typeof (body as { copyFrom?: unknown }).copyFrom === "string") {
      copyFrom = (body as { copyFrom: string }).copyFrom;
    }
  } catch {
    /* empty body = fresh quotation from the template */
  }
  try {
    const { id, doc } = await createQuotation(copyFrom);
    return Response.json({ ok: true, id, doc }, { status: 201 });
  } catch (err) {
    console.error("createQuotation failed", err);
    return Response.json({ ok: false, error: "Could not create quotation" }, { status: 500 });
  }
}
