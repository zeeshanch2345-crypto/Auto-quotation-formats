import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { documents, quotations } from "@/db/schema";
import { cloneDefault, normalizeDoc, type QuoteDoc, type QuotationMeta } from "@/lib/quote";

const LEGACY_ID = "main";
let ensured: Promise<void> | null = null;

/** Creates both tables if they do not exist yet (safe on fresh databases),
 *  then migrates any legacy single-document save into the quotations table. */
function ensureTables(): Promise<void> {
  if (!ensured) {
    ensured = db
      .execute(
        sql`CREATE TABLE IF NOT EXISTS "quotations" (
          "id" text PRIMARY KEY NOT NULL,
          "name" text NOT NULL,
          "data" jsonb NOT NULL,
          "created_at" timestamp with time zone DEFAULT now() NOT NULL,
          "updated_at" timestamp with time zone DEFAULT now() NOT NULL
        )`,
      )
      .then(() =>
        db.execute(
          sql`CREATE TABLE IF NOT EXISTS "documents" (
            "id" text PRIMARY KEY NOT NULL,
            "data" jsonb NOT NULL,
            "updated_at" timestamp with time zone DEFAULT now() NOT NULL
          )`,
        ),
      )
      .then(() => migrateLegacy())
      .catch((err) => {
        ensured = null;
        throw err;
      });
  }
  return ensured;
}

function quoteName(doc: QuoteDoc): string {
  const client = doc.info[1]?.value || doc.info[0]?.value || "";
  return [doc.quotationNo || "Untitled", client, doc.date].filter(Boolean).join(" · ").slice(0, 140);
}

/** One-time migration: the old single "main" document becomes a quotation. */
async function migrateLegacy(): Promise<void> {
  try {
    const existing = await db.select({ id: quotations.id }).from(quotations).limit(1);
    if (existing.length > 0) return;
    const legacy = await db.select().from(documents).where(eq(documents.id, LEGACY_ID)).limit(1);
    if (legacy.length === 0) return;
    const doc = normalizeDoc(legacy[0].data);
    await db.insert(quotations).values({ id: LEGACY_ID, name: quoteName(doc), data: doc });
    await db.delete(documents).where(eq(documents.id, LEGACY_ID));
  } catch (err) {
    console.error("legacy migration failed", err);
  }
}

const toMeta = (r: { id: string; name: string; updatedAt: Date }): QuotationMeta => ({
  id: r.id,
  name: r.name,
  updatedAt: r.updatedAt.toISOString(),
});

export async function listQuotations(): Promise<{ quotations: QuotationMeta[]; activeId: string }> {
  try {
    await ensureTables();
    const rows = await db.select().from(quotations).orderBy(desc(quotations.updatedAt)).limit(200);
    return { quotations: rows.map(toMeta), activeId: rows[0]?.id ?? LEGACY_ID };
  } catch (err) {
    console.error("listQuotations failed", err);
    return { quotations: [], activeId: LEGACY_ID };
  }
}

export async function loadQuotation(id: string): Promise<{ doc: QuoteDoc; updatedAt: string | null }> {
  try {
    await ensureTables();
    const rows = await db.select().from(quotations).where(eq(quotations.id, id)).limit(1);
    if (rows.length === 0) return { doc: cloneDefault(), updatedAt: null };
    return { doc: normalizeDoc(rows[0].data), updatedAt: rows[0].updatedAt.toISOString() };
  } catch (err) {
    console.error("loadQuotation failed", err);
    return { doc: cloneDefault(), updatedAt: null };
  }
}

export async function createQuotation(copyFrom?: string): Promise<{ id: string; doc: QuoteDoc }> {
  await ensureTables();
  let doc = cloneDefault();
  if (copyFrom) {
    const rows = await db.select().from(quotations).where(eq(quotations.id, copyFrom)).limit(1);
    if (rows.length > 0) doc = normalizeDoc(rows[0].data);
  }
  const id = `q${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  const now = new Date();
  await db.insert(quotations).values({ id, name: quoteName(doc), data: doc, createdAt: now, updatedAt: now });
  return { id, doc };
}

export async function saveQuotation(id: string, input: unknown): Promise<{ doc: QuoteDoc; updatedAt: string }> {
  await ensureTables();
  const doc = normalizeDoc(input);
  const now = new Date();
  const name = quoteName(doc);
  await db
    .insert(quotations)
    .values({ id, name, data: doc, createdAt: now, updatedAt: now })
    .onConflictDoUpdate({ target: quotations.id, set: { data: doc, name, updatedAt: now } });
  return { doc, updatedAt: now.toISOString() };
}

export async function deleteQuotation(id: string): Promise<void> {
  await ensureTables();
  await db.delete(quotations).where(eq(quotations.id, id));
}

/* ------- Compatibility helpers for the original /api/doc endpoints ------- */

export async function loadDoc(): Promise<{ doc: QuoteDoc; updatedAt: string | null }> {
  const { activeId } = await listQuotations();
  return loadQuotation(activeId);
}

export async function saveDoc(input: unknown): Promise<{ doc: QuoteDoc; updatedAt: string }> {
  const { activeId } = await listQuotations();
  return saveQuotation(activeId, input);
}
