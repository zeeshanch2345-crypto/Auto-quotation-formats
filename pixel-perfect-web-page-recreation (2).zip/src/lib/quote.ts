// Shared quotation document model (used by server + client).

export type BoqRow = {
  id: string;
  discipline: string;
  /** When true the discipline cell is merged with the row above (rowspan). */
  merge: boolean;
  category: string;
  /** Optional smaller text rendered after the category, e.g. "(Aramco approved)". */
  note: string;
  qty: string;
  unit: string;
  rate: string;
};

export type Bullet = { id: string; text: string };

export type Section = {
  id: string;
  num: string;
  title: string;
  /** "deep" = indented bullets (Payment / General), "flat" = validity style. */
  style: "deep" | "flat";
  /** Vertical space (px) before the heading — reproduces the original rhythm. */
  gap: number;
  bullets: Bullet[];
};

export type InfoRow = { id: string; label: string; value: string };

/** A saved quotation entry shown in the side-panel switcher. */
export type QuotationMeta = { id: string; name: string; updatedAt: string };

export type Letterhead = {
  /** A whole-page image per uploaded PDF page; images repeat in repeat mode. */
  pages: string[];
  enabled: boolean;
  mode: "repeat" | "per-page";
  fit: "contain" | "cover";
  /** "letterhead" keeps room for a full-page header; compact uses the top area. */
  spacing: "letterhead" | "compact";
};

export type QuoteDoc = {
  v: 1;
  labels: { date: string; quotation: string; rev: string };
  date: string;
  quotationNo: string;
  rev: string;
  title: string;
  info: InfoRow[];
  boqLetter: string;
  boqTitle: string;
  cols: { sr: string; discipline: string; category: string; qty: string; unit: string; rate: string };
  boq: BoqRow[];
  termsLetter: string;
  termsTitle: string;
  sections: Section[];
  closing: string;
  regards: string;
  signer: { name: string; title: string; mobile: string; emailLabel: string; email: string; company: string };
  letterhead: Letterhead;
};

let counter = 0;
export function uid(prefix = "x"): string {
  counter = (counter + 1) % 1e6;
  return `${prefix}${Date.now().toString(36)}${counter.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

const row = (
  id: string,
  discipline: string,
  merge: boolean,
  category: string,
  note: string,
  rate: string,
): BoqRow => ({ id, discipline, merge, category, note, qty: "1", unit: "Man-hour", rate });

export const DEFAULT_DOC: QuoteDoc = {
  v: 1,
  labels: { date: "Date:", quotation: "Quotation No.:", rev: "Rev:" },
  date: "November 15, 2026",
  quotationNo: "QTN-106-00",
  rev: "00",
  title: "Commercial Offer",
  info: [
    { id: "i1", label: "Attention To:", value: "Mr. Bjorn Aguilar" },
    { id: "i2", label: "Client / Company:", value: "Bin Quraya Company Limited" },
    { id: "i3", label: "Subject:", value: "Commercial Offer for the Supply of Rental Manpower" },
    { id: "i4", label: "Project / Location:", value: "Jazan Project" },
    { id: "i5", label: "RFQ / SR No:", value: "" },
  ],
  boqLetter: "A.",
  boqTitle: "Bill of Quantities (BOQ)",
  cols: {
    sr: "Sr No.",
    discipline: "Discipline",
    category: "Personnel Category",
    qty: "QTY",
    unit: "Unit",
    rate: "Unit Rate (SAR)",
  },
  boq: [
    row("r1", "HSE", false, "Work Permit Receiver - Aramco Certified", "", "48.00"),
    row("r2", "HSE", true, "HSE Supervisor", "(Aramco approved)", "56.00"),
    row("r3", "HSE", true, "HSE Trainor (Aramco approved)", "", "55.00"),
    row("r4", "HSE", true, "HSE Officer (Aramco approved)", "", "38.00"),
    row("r5", "HSE", true, "Fire Watch TUV", "", "18.00"),
    row("r6", "Rigging", false, "Rigger III", "(Aramco Certified)", "60.00"),
    row("r7", "Welding", false, "Multi Welder", "", "50.00"),
    row("r8", "Scaffolding", false, "Scaffolder TUV", "", "20.00"),
    row("r9", "Civil", false, "Steel Fixer / Carpenter", "", "18.00"),
    row("r10", "General Labour", false, "Helper", "", "14.00"),
  ],
  termsLetter: "B.",
  termsTitle: "Terms and Conditions:",
  sections: [
    {
      id: "s1",
      num: "1.",
      title: "Payment Terms:",
      style: "deep",
      gap: 17.6,
      bullets: [
        {
          id: "b1",
          text: "A 15% Value Added Tax (VAT) shall be applicable in accordance with the prevailing laws and regulations of the Kingdom of Saudi Arabia.",
        },
        { id: "b2", text: "Payment shall be made within thirty (30) calendar days from the date of invoice submission." },
      ],
    },
    {
      id: "s2",
      num: "2.",
      title: "General Conditions:",
      style: "deep",
      gap: 37.3,
      bullets: [
        {
          id: "b3",
          text: "Standard working hours shall be ten (10) hours per day, six (6) days per week, and twenty-six (26) working days per month, equivalent to 260 working hours per month.",
        },
        {
          id: "b4",
          text: "Any working hours exceeding the agreed schedule shall be considered overtime and charged accordingly.",
        },
        { id: "b5", text: "Food, accommodation and Transportation shall be provided by Client." },
        { id: "b6", text: "Personal Protective Equipment (PPE) shall be provided by UIC." },
        { id: "b7", text: "On-site first aid facilities and services shall be provided by Client." },
      ],
    },
    {
      id: "s3",
      num: "3.",
      title: "Validity",
      style: "flat",
      gap: 18.55,
      bullets: [
        {
          id: "b8",
          text: "This quotation is valid for 14 calendar days from the date of issue. Rates are based on prevailing market conditions and manpower availability. UIC reserves the right to revise quoted rates if actual manpower sourcing costs or market conditions change, subject to the Client\u2019s prior approval.",
        },
      ],
    },
  ],
  closing:
    "For any queries, please do not hesitate to contact the undersigned. We look forward to building a strong and professional relationship with your esteemed organization.",
  regards: "Best Regards,",
  signer: {
    name: "Nouman Ansari",
    title: "Sr. Dawood Ahmed",
    mobile: "Mob: +966 562899514",
    emailLabel: "Email:",
    email: "info@theuniqueinnovations.com",
    company: "Unique Innovations Company (UIC)",
  },
  letterhead: {
    pages: [],
    enabled: false,
    mode: "repeat",
    fit: "contain",
    spacing: "compact",
  },
};

/* ------------------------------------------------------------------ */
/* Defensive normalisation so stored / posted JSON always has a valid  */
/* shape (missing keys fall back to defaults, wrong types are coerced). */
/* ------------------------------------------------------------------ */

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === "object" && v !== null && !Array.isArray(v);
const str = (v: unknown, d: string, max = 4000): string =>
  typeof v === "string" ? v.slice(0, max) : typeof v === "number" ? String(v) : d;
const MAX_LETTERHEAD_PAGE_CHARS = 1_350_000;
const MAX_LETTERHEAD_TOTAL_CHARS = 7_000_000;
/** Accepts same-origin proxy URLs (S3-backed), public https URLs, and legacy
 *  in-document data URIs (local fallback storage). */
const letterheadPage = (v: unknown): string => {
  if (typeof v !== "string") return "";
  if (/^\/api\/letterhead\/[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(v)) return v;
  if (/^https:\/\/[^\s"'<>]{1,200}$/.test(v)) return v;
  if (v.length <= MAX_LETTERHEAD_PAGE_CHARS && /^data:image\/(?:webp|png|jpeg|jpg|avif);base64,/i.test(v)) return v;
  return "";
};
const sid = (v: unknown, prefix: string): string =>
  typeof v === "string" && v.length > 0 && v.length < 64 ? v : uid(prefix);

function pick<T extends Record<string, string>>(src: unknown, def: T): T {
  const o = isObj(src) ? src : {};
  const out = { ...def };
  (Object.keys(def) as (keyof T)[]).forEach((k) => {
    out[k] = str(o[k as string], def[k]) as T[keyof T];
  });
  return out;
}

export function normalizeDoc(input: unknown): QuoteDoc {
  const d = DEFAULT_DOC;
  const o = isObj(input) ? input : {};

  const info: InfoRow[] = Array.isArray(o.info)
    ? (o.info as unknown[]).slice(0, 40).map((r, i) => {
        const x = isObj(r) ? r : {};
        return { id: sid(x.id, "i"), label: str(x.label, d.info[i]?.label ?? ""), value: str(x.value, "") };
      })
    : d.info.map((r) => ({ ...r }));

  const boq: BoqRow[] = Array.isArray(o.boq)
    ? (o.boq as unknown[]).slice(0, 300).map((r, i) => {
        const x = isObj(r) ? r : {};
        return {
          id: sid(x.id, "r"),
          discipline: str(x.discipline, ""),
          merge: i > 0 && x.merge === true,
          category: str(x.category, ""),
          note: str(x.note, ""),
          qty: str(x.qty, ""),
          unit: str(x.unit, ""),
          rate: str(x.rate, ""),
        };
      })
    : d.boq.map((r) => ({ ...r }));

  const sections: Section[] = Array.isArray(o.sections)
    ? (o.sections as unknown[]).slice(0, 30).map((s, i) => {
        const x = isObj(s) ? s : {};
        const def = d.sections[i] ?? d.sections[d.sections.length - 1];
        const gap = typeof x.gap === "number" && isFinite(x.gap) ? Math.max(0, Math.min(200, x.gap)) : def.gap;
        return {
          id: sid(x.id, "s"),
          num: str(x.num, def.num),
          title: str(x.title, def.title),
          style: x.style === "flat" ? "flat" : x.style === "deep" ? "deep" : def.style,
          gap,
          bullets: Array.isArray(x.bullets)
            ? (x.bullets as unknown[]).slice(0, 200).map((b) => {
                const y = isObj(b) ? b : {};
                return { id: sid(y.id, "b"), text: str(y.text, "") };
              })
            : def.bullets.map((b) => ({ ...b })),
        };
      })
    : d.sections.map((s) => ({ ...s, bullets: s.bullets.map((b) => ({ ...b })) }));

  const rawLetterhead = isObj(o.letterhead) ? o.letterhead : {};
  const pages: string[] = [];
  let pageChars = 0;
  if (Array.isArray(rawLetterhead.pages)) {
    for (const value of rawLetterhead.pages.slice(0, 8)) {
      const page = letterheadPage(value);
      if (!page || pageChars + page.length > MAX_LETTERHEAD_TOTAL_CHARS) continue;
      pages.push(page);
      pageChars += page.length;
    }
  }
  const letterhead: Letterhead = {
    pages,
    enabled: rawLetterhead.enabled === true && pages.length > 0,
    mode: rawLetterhead.mode === "per-page" && pages.length > 1 ? "per-page" : "repeat",
    fit: rawLetterhead.fit === "cover" ? "cover" : "contain",
    spacing: rawLetterhead.spacing === "letterhead" ? "letterhead" : "compact",
  };

  return {
    v: 1,
    labels: pick(o.labels, d.labels),
    date: str(o.date, d.date),
    quotationNo: str(o.quotationNo, d.quotationNo),
    rev: str(o.rev, d.rev),
    title: str(o.title, d.title),
    info,
    boqLetter: str(o.boqLetter, d.boqLetter),
    boqTitle: str(o.boqTitle, d.boqTitle),
    cols: pick(o.cols, d.cols),
    boq,
    termsLetter: str(o.termsLetter, d.termsLetter),
    termsTitle: str(o.termsTitle, d.termsTitle),
    sections,
    closing: str(o.closing, d.closing),
    regards: str(o.regards, d.regards),
    signer: pick(o.signer, d.signer),
    letterhead,
  };
}

export function cloneDefault(): QuoteDoc {
  return normalizeDoc(JSON.parse(JSON.stringify(DEFAULT_DOC)));
}
