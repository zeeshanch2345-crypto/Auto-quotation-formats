import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { Readable } from "node:stream";

let client: S3Client | null = null;

function getClient(): S3Client | null {
  const { AWS_ENDPOINT_URL_S3, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION } = process.env;
  if (!AWS_ENDPOINT_URL_S3 || !AWS_ACCESS_KEY_ID || !AWS_SECRET_ACCESS_KEY || !AWS_REGION) return null;
  if (!client) {
    client = new S3Client({
      region: AWS_REGION,
      endpoint: AWS_ENDPOINT_URL_S3,
      credentials: {
        accessKeyId: AWS_ACCESS_KEY_ID,
        secretAccessKey: AWS_SECRET_ACCESS_KEY,
      },
      forcePathStyle: true,
    });
  }
  return client;
}

export const LETTERHEAD_BUCKET = process.env.S3_BUCKET || "quotation-letterheads";
const KEY_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;

export function isValidLetterheadKey(key: string): boolean {
  return KEY_RE.test(key);
}

export function isLetterheadConfigured(): boolean {
  return getClient() !== null;
}

export async function putLetterheadObject(key: string, body: Buffer, contentType: string): Promise<void> {
  const c = getClient();
  if (!c) throw new Error("S3 is not configured");
  await c.send(
    new PutObjectCommand({
      Bucket: LETTERHEAD_BUCKET,
      Key: key,
      Body: body,
      ContentType: contentType,
    }),
  );
}

export async function getLetterheadObject(
  key: string,
): Promise<{ body: ReadableStream<Uint8Array>; contentType: string; length?: number } | null> {
  const c = getClient();
  if (!c) return null;
  try {
    const obj = await c.send(new GetObjectCommand({ Bucket: LETTERHEAD_BUCKET, Key: key }));
    if (!obj.Body) return null;
    const raw = obj.Body as unknown;
    let stream: ReadableStream<Uint8Array>;
    if (raw instanceof Readable) {
      stream = Readable.toWeb(raw) as ReadableStream<Uint8Array>;
    } else if (raw instanceof Blob) {
      stream = raw.stream();
    } else if (raw && typeof (raw as { getReader?: unknown }).getReader === "function") {
      stream = raw as ReadableStream<Uint8Array>;
    } else {
      return null;
    }
    return { body: stream, contentType: obj.ContentType ?? "application/octet-stream", length: obj.ContentLength };
  } catch {
    return null;
  }
}
