"use client";

import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type FormEvent,
  type KeyboardEvent as RKeyboardEvent,
  type ReactNode,
} from "react";
import { cloneDefault, uid, type QuotationMeta, type QuoteDoc } from "@/lib/quote";
import StudioSidebar, { type SaveStatus } from "./StudioSidebar";
import { MAX_LETTERHEAD_PAGES, prepareLetterhead } from "./letterhead-utils";

const LETTERHEAD_TOP = 229.5;
const LETTERHEAD_BOTTOM = 1012;
const COMPACT_TOP = 82;
const COMPACT_BOTTOM = 1088;
const PAD = {
  info: 40.6,
  boqh: 19.55,
  boq: 17.15,
  terms: 18.45,
  firstDeep: 18.35,
  firstFlat: 2.5,
  bullet: 0.4,
  closing: 56.75,
  sign: 38.95,
};

type Kind = "title" | "info" | "boqh" | "boq" | "terms" | "sech" | "bullet" | "closing" | "sign";
type Block = { k: Kind; key: string; pad: number; keep?: boolean; sid?: string; bid?: string; from?: number; to?: number };
type Placed = Block & { padUsed: number };
type Measure = { h: Record<string, number>; head: number; rows: number[]; extra: number };
type UploadStatus = { busy: boolean; progress: string; error: string };

type LayoutMode = "letterhead" | "compact";

function getLayout(doc: QuoteDoc): LayoutMode {
  return doc.letterhead.enabled && doc.letterhead.pages.length > 0 && doc.letterhead.spacing === "letterhead" ? "letterhead" : "compact";
}

function availableHeight(mode: LayoutMode): number {
  return (mode === "letterhead" ? LETTERHEAD_BOTTOM : COMPACT_BOTTOM) -
    (mode === "letterhead" ? LETTERHEAD_TOP : COMPACT_TOP);
}

function buildBlocks(doc: QuoteDoc): Block[] {
  const out: Block[] = [
    { k: "title", key: "title", pad: 0 },
    { k: "info", key: "info", pad: PAD.info },
    { k: "boqh", key: "boqh", pad: PAD.boqh, keep: true },
    { k: "boq", key: "boq", pad: PAD.boq, from: 0, to: doc.boq.length },
    { k: "terms", key: "terms", pad: PAD.terms, keep: true },
  ];
  for (const section of doc.sections) {
    out.push({ k: "sech", key: `sec-${section.id}`, pad: section.gap, keep: true, sid: section.id });
    section.bullets.forEach((bullet, index) =>
      out.push({
        k: "bullet",
        key: `li-${bullet.id}`,
        pad: index === 0 ? (section.style === "flat" ? PAD.firstFlat : PAD.firstDeep) : PAD.bullet,
        sid: section.id,
        bid: bullet.id,
      }),
    );
  }
  out.push({ k: "closing", key: "closing", pad: PAD.closing });
  out.push({ k: "sign", key: "sign", pad: PAD.sign });
  return out;
}

function blockHeight(block: Block, measure: Measure): number {
  if (block.k === "boq") return block.pad + measure.head + measure.extra + (measure.rows[0] ?? 0);
  return measure.h[block.key] ?? 20;
}

function paginate(blocks: Block[], measure: Measure, available: number): Placed[][] {
  const pages: Placed[][] = [[]];
  let y = 0;
  const newPage = () => {
    pages.push([]);
    y = 0;
  };

  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i];
    if (block.k === "boq") {
      const rowCount = measure.rows.length;
      let from = 0;
      for (let guard = 0; guard < 400; guard++) {
        const pad = y === 0 ? 0 : block.pad;
        let height = pad + measure.head + measure.extra;
        let to = from;
        while (to < rowCount && y + height + measure.rows[to] <= available) {
          height += measure.rows[to];
          to++;
        }
        if (to === from && rowCount > 0) {
          if (y > 0) {
            newPage();
            continue;
          }
          height += measure.rows[to];
          to++;
        }
        pages[pages.length - 1].push({
          ...block,
          key: from === 0 ? block.key : `${block.key}-${from}`,
          from,
          to,
          padUsed: pad,
        });
        y += height;
        from = to;
        if (from >= rowCount) break;
        newPage();
      }
      continue;
    }

    const full = measure.h[block.key] ?? 20;
    let pad = y === 0 ? 0 : block.pad;
    let height = full - block.pad + pad;
    let keepHeight = height;
    if (block.keep) {
      for (let j = i + 1; j < blocks.length; j++) {
        keepHeight += blockHeight(blocks[j], measure);
        if (!blocks[j].keep) break;
      }
    }
    if (y > 0 && y + keepHeight > available) {
      newPage();
      pad = 0;
      height = full - block.pad;
    }
    pages[pages.length - 1].push({ ...block, padUsed: pad });
    y += height;
  }
  return pages;
}

function samePages(a: Placed[][], b: Placed[][]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i].length !== b[i].length) return false;
    for (let j = 0; j < a[i].length; j++) {
      const left = a[i][j];
      const right = b[i][j];
      if (left.key !== right.key || Math.abs(left.padUsed - right.padUsed) > 0.01 || left.from !== right.from || left.to !== right.to) return false;
    }
  }
  return true;
}

function wrapLines(text: string, width: number, characterWidth: number): number {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (!words.length) return 1;
  let lines = 1;
  let used = 0;
  for (const word of words) {
    const widthOfWord = word.length * characterWidth;
    const next = used === 0 ? widthOfWord : used + characterWidth + widthOfWord;
    if (next > width && used > 0) {
      lines++;
      used = widthOfWord;
    } else used = next;
  }
  return lines;
}

function estimateMeasure(doc: QuoteDoc, blocks: Block[]): Measure {
  const h: Record<string, number> = {};
  for (const block of blocks) {
    if (block.k === "title") h[block.key] = 27.5;
    else if (block.k === "info") h[block.key] = block.pad + doc.info.length * 27.84 + 1.33;
    else if (block.k === "boqh") h[block.key] = block.pad + 19.5;
    else if (block.k === "terms" || block.k === "sech") h[block.key] = block.pad + 17.9;
    else if (block.k === "bullet") {
      const section = doc.sections.find((item) => item.id === block.sid);
      const text = section?.bullets.find((item) => item.id === block.bid)?.text ?? "";
      h[block.key] = block.pad + (section?.style === "flat" ? wrapLines(text, 635.4, 6.05) * 17.5 : wrapLines(text, 612, 6.3) * 17.9);
    } else if (block.k === "closing") h[block.key] = block.pad + wrapLines(doc.closing, 666.2, 6.2) * 17.8;
    else if (block.k === "sign") h[block.key] = block.pad + 162;
  }
  const rows = doc.boq.map((row) => wrapLines(`${row.category} ${row.note}`, 264, 5.9) * 17.24 + 1);
  return { h, head: 36, rows, extra: 1 };
}

function readMeasure(root: HTMLElement): Measure {
  const h: Record<string, number> = {};
  root.querySelectorAll<HTMLElement>("[data-mkey]").forEach((element) => {
    h[element.dataset.mkey as string] = element.getBoundingClientRect().height;
  });
  let head = 36;
  const rows: number[] = [];
  let extra = 1.33;
  const table = root.querySelector<HTMLElement>('[data-mkey="boq"] table');
  if (table) {
    const thead = table.querySelector("thead");
    head = thead ? thead.getBoundingClientRect().height : 0;
    rows.push(...Array.from(table.querySelectorAll("tbody > tr"), (row) => row.getBoundingClientRect().height));
    extra = Math.max(0, table.getBoundingClientRect().height - head - rows.reduce((sum, value) => sum + value, 0));
  }
  return { h, head, rows, extra };
}

function getCaret(element: HTMLElement): number {
  const selection = window.getSelection();
  if (!selection || selection.rangeCount === 0) return 0;
  const range = selection.getRangeAt(0);
  if (!element.contains(range.startContainer)) return 0;
  const prefix = document.createRange();
  prefix.selectNodeContents(element);
  prefix.setEnd(range.startContainer, range.startOffset);
  return prefix.toString().length;
}

function setCaret(element: HTMLElement, offset: number) {
  element.focus({ preventScroll: true });
  const selection = window.getSelection();
  if (!selection) return;
  const range = document.createRange();
  let remaining = Math.max(0, offset);
  const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  while (node) {
    const length = node.textContent?.length ?? 0;
    if (remaining <= length) {
      range.setStart(node, remaining);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
      return;
    }
    remaining -= length;
    node = walker.nextNode();
  }
  range.selectNodeContents(element);
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);
}

type EditorApi = { editable: boolean; update: (fn: (doc: QuoteDoc) => void) => void; focus: (fid: string, offset: number) => void };
const ApiContext = createContext<EditorApi>({ editable: false, update: () => {}, focus: () => {} });
const MeasureContext = createContext(false);

function Field({
  id,
  value,
  onChange,
  as = "span",
  className,
  placeholder,
  onKeyDown,
}: {
  id: string;
  value: string;
  onChange: (value: string) => void;
  as?: "span" | "div";
  className?: string;
  placeholder?: string;
  onKeyDown?: (event: RKeyboardEvent<HTMLElement>, element: HTMLElement) => boolean;
}) {
  const measuring = useContext(MeasureContext);
  const { editable } = useContext(ApiContext);
  const elementRef = useRef<HTMLElement | null>(null);
  const [initial] = useState(value);
  useLayoutEffect(() => {
    const element = elementRef.current;
    if (element && element.textContent !== value && document.activeElement !== element) element.textContent = value;
  }, [value]);
  if (measuring) return createElement(as, { className }, value);
  return createElement(
    as,
    {
      ref: (element: HTMLElement | null) => { elementRef.current = element; },
      className: className ? `q-f ${className}` : "q-f",
      "data-fid": id,
      "data-ph": placeholder ?? "Click to edit",
      contentEditable: editable ? "plaintext-only" : undefined,
      suppressContentEditableWarning: true,
      spellCheck: false,
      onInput: (event: FormEvent<HTMLElement>) => {
        const element = event.currentTarget;
        const text = element.textContent ?? "";
        if (!text && element.innerHTML) element.innerHTML = "";
        onChange(text);
      },
      onKeyDown: (event: RKeyboardEvent<HTMLElement>) => {
        if (onKeyDown?.(event, event.currentTarget)) return;
        if (event.key === "Enter") event.preventDefault();
      },
      onPaste: (event: React.ClipboardEvent<HTMLElement>) => {
        event.preventDefault();
        const text = event.clipboardData.getData("text/plain").replace(/\s*[\r\n]+\s*/g, " ");
        document.execCommand("insertText", false, text);
      },
    },
    initial,
  );
}

function Controls({ children, className }: { children: ReactNode; className: string }) {
  if (useContext(MeasureContext) || !useContext(ApiContext).editable) return null;
  return <span className={`q-ctl ${className}`} contentEditable={false}>{children}</span>;
}

function HeaderTable({ doc }: { doc: QuoteDoc }) {
  const { update } = useContext(ApiContext);
  return (
    <table className="q-hdr rv" aria-label="Quotation reference">
      <colgroup><col style={{ width: 81.1 }} /><col style={{ width: 183.4 }} /><col style={{ width: 125.8 }} /><col style={{ width: 156 }} /><col style={{ width: 76.8 }} /><col style={{ width: 84.5 }} /></colgroup>
      <tbody><tr>
        <td><Field as="div" id="ld" value={doc.labels.date} onChange={(v) => update((d) => { d.labels.date = v; })} /></td>
        <td className="v"><Field as="div" id="date" value={doc.date} onChange={(v) => update((d) => { d.date = v; })} /></td>
        <td><Field as="div" id="lq" value={doc.labels.quotation} onChange={(v) => update((d) => { d.labels.quotation = v; })} /></td>
        <td className="v"><Field as="div" id="qn" value={doc.quotationNo} onChange={(v) => update((d) => { d.quotationNo = v; })} /></td>
        <td><Field as="div" id="lr" value={doc.labels.rev} onChange={(v) => update((d) => { d.labels.rev = v; })} /></td>
        <td className="v"><Field as="div" id="rev" value={doc.rev} onChange={(v) => update((d) => { d.rev = v; })} /></td>
      </tr></tbody>
    </table>
  );
}

function InfoTable({ doc }: { doc: QuoteDoc }) {
  const { update } = useContext(ApiContext);
  return (
    <table className="q-info" aria-label="Recipient and project details">
      <colgroup><col style={{ width: 166.6 }} /><col /></colgroup>
      <tbody>{doc.info.map((row, index) => (
        <tr key={row.id}>
          <td><Field as="div" id={`il-${row.id}`} value={row.label} onChange={(v) => update((d) => { if (d.info[index]) d.info[index].label = v; })} /></td>
          <td className="v"><Field as="div" id={`iv-${row.id}`} value={row.value} placeholder="Click to add" onChange={(v) => update((d) => { if (d.info[index]) d.info[index].value = v; })} /></td>
        </tr>
      ))}</tbody>
    </table>
  );
}

function BoqTable({ doc, from, to }: { doc: QuoteDoc; from: number; to: number }) {
  const { update } = useContext(ApiContext);
  const rows = doc.boq.slice(from, Math.min(to, doc.boq.length));
  const insertRow = (index: number) => update((d) => {
    const base = d.boq[index];
    d.boq.splice(index + 1, 0, { id: uid("r"), discipline: base?.discipline ?? "", merge: false, category: "", note: "", qty: base?.qty ?? "1", unit: base?.unit ?? "Man-hour", rate: "" });
  });
  return (
    <table className="q-boq" aria-label="Bill of quantities">
      <colgroup><col style={{ width: 46.1 }} /><col style={{ width: 146.9 }} /><col style={{ width: 279.4 }} /><col style={{ width: 49 }} /><col style={{ width: 83 }} /><col style={{ width: 103.2 }} /></colgroup>
      <thead><tr>{(["sr", "discipline", "category", "qty", "unit", "rate"] as const).map((column) => <th key={column}><Field as="div" id={`col-${column}`} value={doc.cols[column]} onChange={(v) => update((d) => { d.cols[column] = v; })} /></th>)}</tr></thead>
      <tbody>
        {rows.map((row, offset) => {
          const index = from + offset;
          let span = 0;
          let groupHead = index;
          if (offset === 0 || !row.merge) {
            span = 1;
            while (index + span < Math.min(to, doc.boq.length) && doc.boq[index + span].merge) span++;
            while (groupHead > 0 && doc.boq[groupHead].merge) groupHead--;
          }
          const setGroup = (value: string) => update((d) => {
            if (!d.boq[groupHead]) return;
            d.boq[groupHead].discipline = value;
            for (let j = groupHead + 1; j < d.boq.length && d.boq[j].merge; j++) d.boq[j].discipline = value;
          });
          const set = (key: "category" | "note" | "qty" | "unit" | "rate") => (value: string) => update((d) => { if (d.boq[index]) d.boq[index][key] = value; });
          return (
            <tr key={row.id}>
              <td className="c">{index + 1}</td>
              {span > 0 && <td className="d" rowSpan={span}><Field as="div" id={`bd-${row.id}`} value={doc.boq[groupHead].discipline} placeholder="Discipline" onChange={setGroup} /></td>}
              <td className="cat"><Field id={`bc-${row.id}`} value={row.category} placeholder="Personnel category" onChange={set("category")} />{row.note ? " " : null}<Field className={`q-note${row.note ? "" : " q-note-empty"}`} id={`bn-${row.id}`} value={row.note} placeholder="(note)" onChange={set("note")} /></td>
              <td className="c"><Field as="div" id={`bq-${row.id}`} value={row.qty} placeholder="0" onChange={set("qty")} /></td>
              <td className="c"><Field as="div" id={`bu-${row.id}`} value={row.unit} placeholder="Unit" onChange={set("unit")} /></td>
              <td className="c last"><Field as="div" id={`br-${row.id}`} value={row.rate} placeholder="0.00" onChange={set("rate")} />
                <Controls className="q-rowctl"><button type="button" title="Insert a line below" aria-label="Insert a line below" onClick={() => insertRow(index)}>+</button>
                  {index > 0 && <button type="button" className={row.merge ? "on" : ""} title={row.merge ? "Unmerge discipline" : "Merge discipline with the row above"} aria-label="Toggle merged discipline" onClick={() => update((d) => { const current = d.boq[index]; current.merge = !current.merge; if (current.merge) { let head = index - 1; while (head > 0 && d.boq[head].merge) head--; current.discipline = d.boq[head].discipline; } })}>⇡</button>}
                  <button type="button" title="Delete line" aria-label="Delete line" onClick={() => update((d) => { const removed = d.boq.splice(index, 1)[0]; const next = d.boq[index]; if (removed && !removed.merge && next?.merge) { next.merge = false; next.discipline = removed.discipline; } if (d.boq[0]) d.boq[0].merge = false; })}>×</button>
                </Controls>
              </td>
            </tr>
          );
        })}
        {doc.boq.length === 0 && <tr><td colSpan={6} className="c"><Controls className="q-addrow"><button type="button" onClick={() => insertRow(-1)}>+ Add line item</button></Controls></td></tr>}
      </tbody>
    </table>
  );
}

function BulletItem({ doc, sectionId, bulletId }: { doc: QuoteDoc; sectionId: string; bulletId: string }) {
  const { update, focus } = useContext(ApiContext);
  const sectionIndex = doc.sections.findIndex((section) => section.id === sectionId);
  const section = doc.sections[sectionIndex];
  const bulletIndex = section?.bullets.findIndex((bullet) => bullet.id === bulletId) ?? -1;
  if (!section || bulletIndex < 0) return null;
  const bullet = section.bullets[bulletIndex];
  const onKeyDown = (event: RKeyboardEvent<HTMLElement>, element: HTMLElement): boolean => {
    if (event.key === "Enter") {
      event.preventDefault();
      const text = element.textContent ?? "";
      const offset = getCaret(element);
      const before = text.slice(0, offset).replace(/\s+$/, "");
      const after = text.slice(offset).replace(/^\s+/, "");
      element.textContent = before;
      const id = uid("b");
      update((d) => { const current = d.sections[sectionIndex]; current.bullets[bulletIndex].text = before; current.bullets.splice(bulletIndex + 1, 0, { id, text: after }); });
      focus(`li-${id}`, 0);
      return true;
    }
    if (event.key === "Backspace" && window.getSelection()?.isCollapsed && getCaret(element) === 0 && bulletIndex > 0) {
      event.preventDefault();
      const previous = section.bullets[bulletIndex - 1];
      const text = element.textContent ?? "";
      const caret = previous.text.length + (previous.text && text ? 1 : 0);
      update((d) => { d.sections[sectionIndex].bullets[bulletIndex - 1].text = previous.text + (previous.text && text ? " " : "") + text; d.sections[sectionIndex].bullets.splice(bulletIndex, 1); });
      focus(`li-${previous.id}`, caret);
      return true;
    }
    return false;
  };
  return (
    <p className={`q-li ${section.style === "flat" ? "flat" : "deep"}`}>
      <Field id={`li-${bullet.id}`} value={bullet.text} placeholder="Type a condition" onKeyDown={onKeyDown} onChange={(value) => update((d) => { const found = d.sections[sectionIndex]?.bullets.find((item) => item.id === bulletId); if (found) found.text = value; })} />
      <Controls className="q-lictl">
        <button type="button" title="Add a condition below" aria-label="Add a condition below" onClick={() => { const id = uid("b"); update((d) => { d.sections[sectionIndex].bullets.splice(bulletIndex + 1, 0, { id, text: "" }); }); focus(`li-${id}`, 0); }}>+</button>
        <button type="button" title="Remove condition" aria-label="Remove condition" onClick={() => update((d) => { d.sections[sectionIndex].bullets.splice(bulletIndex, 1); })}>×</button>
      </Controls>
    </p>
  );
}

function SectionHeading({ doc, sectionId }: { doc: QuoteDoc; sectionId: string }) {
  const { update, focus } = useContext(ApiContext);
  const index = doc.sections.findIndex((section) => section.id === sectionId);
  const section = doc.sections[index];
  if (!section) return null;
  return (
    <h3 className="q-h">
      <Field className="n" id={`sn-${section.id}`} value={section.num} placeholder="1." onChange={(value) => update((d) => { d.sections[index].num = value; })} />
      <Field className="t u" id={`st-${section.id}`} value={section.title} placeholder="Heading" onChange={(value) => update((d) => { d.sections[index].title = value; })} />
      {section.bullets.length === 0 && <Controls className="q-secctl"><button type="button" onClick={() => { const id = uid("b"); update((d) => { d.sections[index].bullets.push({ id, text: "" }); }); focus(`li-${id}`, 0); }}>+ Add condition</button></Controls>}
    </h3>
  );
}

function Signature({ doc }: { doc: QuoteDoc }) {
  const { update } = useContext(ApiContext);
  const set = (key: keyof QuoteDoc["signer"]) => (value: string) => update((d) => { d.signer[key] = value; });
  return (
    <div className="q-sign">
      <div className="q-sl q-regards"><Field id="regards" value={doc.regards} onChange={(value) => update((d) => { d.regards = value; })} /></div>
      <div className="q-sl q-name"><Field id="sg-name" value={doc.signer.name} onChange={set("name")} /></div>
      <div className="q-sl q-s1"><Field id="sg-title" value={doc.signer.title} onChange={set("title")} /></div>
      <div className="q-sl q-s2"><Field id="sg-mob" value={doc.signer.mobile} onChange={set("mobile")} /></div>
      <div className="q-sl q-s3"><Field id="sg-el" value={doc.signer.emailLabel} onChange={set("emailLabel")} />{" "}<span className="q-link"><Field id="sg-email" value={doc.signer.email} onChange={set("email")} /></span></div>
      <div className="q-sl q-s4"><Field id="sg-co" value={doc.signer.company} onChange={set("company")} /></div>
    </div>
  );
}

function BlockView({ block, doc, measure }: { block: Block | Placed; doc: QuoteDoc; measure?: boolean }) {
  const { update } = useContext(ApiContext);
  const paddingTop = "padUsed" in block ? block.padUsed : block.pad;
  const style = { paddingTop, "--delay": measure ? "0s" : "0.06s" } as CSSProperties;
  const wrap = (child: ReactNode) => <div className={measure ? "q-b" : "q-b rv"} style={style} data-mkey={measure ? block.key : undefined}>{child}</div>;
  switch (block.k) {
    case "title": return wrap(<h1 className="q-title"><Field id="title" value={doc.title} placeholder="Quotation title" onChange={(value) => update((d) => { d.title = value; })} /></h1>);
    case "info": return wrap(<InfoTable doc={doc} />);
    case "boqh": return wrap(<h2 className="q-h q-h-a"><Field className="n" id="boq-letter" value={doc.boqLetter} onChange={(value) => update((d) => { d.boqLetter = value; })} /><Field className="t" id="boq-title" value={doc.boqTitle} onChange={(value) => update((d) => { d.boqTitle = value; })} /></h2>);
    case "boq": return wrap(<BoqTable doc={doc} from={block.from ?? 0} to={block.to ?? doc.boq.length} />);
    case "terms": return wrap(<h2 className="q-h"><Field className="n" id="terms-letter" value={doc.termsLetter} onChange={(value) => update((d) => { d.termsLetter = value; })} /><Field className="t u" id="terms-title" value={doc.termsTitle} onChange={(value) => update((d) => { d.termsTitle = value; })} /></h2>);
    case "sech": return wrap(<SectionHeading doc={doc} sectionId={block.sid ?? ""} />);
    case "bullet": return wrap(<BulletItem doc={doc} sectionId={block.sid ?? ""} bulletId={block.bid ?? ""} />);
    case "closing": return wrap(<p className="q-p"><Field id="closing" value={doc.closing} placeholder="Closing message" onChange={(value) => update((d) => { d.closing = value; })} /></p>);
    case "sign": return wrap(<Signature doc={doc} />);
    default: return null;
  }
}

function getBackground(doc: QuoteDoc, page: number): string {
  const letterhead = doc.letterhead;
  if (!letterhead.enabled || letterhead.pages.length === 0) return "";
  if (letterhead.mode === "repeat") return letterhead.pages[0];
  return letterhead.pages[page - 1] ?? letterhead.pages[letterhead.pages.length - 1] ?? "";
}

function Sheet({ doc, page, pageCount, children }: { doc: QuoteDoc; page: number; pageCount: number; children: ReactNode }) {
  const background = getBackground(doc, page);
  const mode = getLayout(doc);
  const style = {
    "--content-top": `${mode === "letterhead" ? LETTERHEAD_TOP : COMPACT_TOP}px`,
    "--header-top": `${mode === "letterhead" ? 188.2 : 36}px`,
  } as CSSProperties;
  return (
    <article className={`q-page${background ? " has-background" : ""}`} style={style} data-page={page} aria-label={`Quotation page ${page}`}>
      {background && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          className={`q-page-background ${doc.letterhead.fit === "cover" ? "fit-cover" : "fit-contain"}`}
          src={background}
          alt=""
          aria-hidden="true"
          draggable={false}
          fetchPriority="high"
        />
      )}
      <div className="q-page-content">
        <HeaderTable doc={doc} />
        <div className="q-flow">{children}</div>
      </div>
      <div className="q-screen-page-number" aria-label={`Page ${page} of ${pageCount}`}>Page {page} <span>/</span> {pageCount}</div>
    </article>
  );
}

function Icon({ name }: { name: "zoom-in" | "zoom-out" | "fit" | "print" }) {
  const paths = {
    "zoom-in": <><circle cx="10.8" cy="10.8" r="6.6" /><path d="m16 16 4 4M10.8 7.8v6m-3-3h6" /></>,
    "zoom-out": <><circle cx="10.8" cy="10.8" r="6.6" /><path d="m16 16 4 4m-12.2-9.2h6" /></>,
    fit: <><path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 1-2 2h-3" /></>,
    print: <><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><path d="M6 14h12v8H6z" /></>,
  };
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export default function QuoteEditor({
  initialState,
}: {
  initialState: { quotations: QuotationMeta[]; activeId: string; initialDoc: QuoteDoc };
}) {
  const [doc, setDoc] = useState<QuoteDoc>(initialState.initialDoc);
  const [quotations, setQuotations] = useState<QuotationMeta[]>(initialState.quotations);
  const [activeId, setActiveId] = useState(initialState.activeId);
  const [editable, setEditable] = useState(false);
  const [status, setStatus] = useState<SaveStatus>("saved");
  const [shareMessage, setShareMessage] = useState("");
  const [upload, setUpload] = useState<UploadStatus>({ busy: false, progress: "", error: "" });
  const [previewZoom, setPreviewZoom] = useState(1);
  const blocks = useMemo(() => buildBlocks(doc), [doc]);
  const layout = getLayout(doc);
  const [pages, setPages] = useState<Placed[][]>(() => {
    const initialBlocks = buildBlocks(initialState.initialDoc);
    return paginate(initialBlocks, estimateMeasure(initialState.initialDoc, initialBlocks), availableHeight(getLayout(initialState.initialDoc)));
  });

  const measureRef = useRef<HTMLDivElement>(null);
  const uploadToken = useRef(0);
  const pendingFocus = useRef<{ id: string; offset: number; force: boolean; time: number } | null>(null);
  const pagesRef = useRef(pages);
  const docRef = useRef(doc);
  const version = useRef(0);
  const savedVersion = useRef(0);
  const saveTimer = useRef<number | undefined>(undefined);
  const firstDoc = useRef(true);
  const activeIdRef = useRef(activeId);
  activeIdRef.current = activeId;
  const skipNextSave = useRef(false);
  pagesRef.current = pages;
  docRef.current = doc;

  const update = useCallback((fn: (document: QuoteDoc) => void) => {
    setDoc((previous) => {
      const next = structuredClone(previous);
      fn(next);
      return next;
    });
  }, []);

  const focus = useCallback((id: string, offset: number) => {
    pendingFocus.current = { id, offset, force: true, time: Date.now() };
  }, []);

  const api = useMemo(() => ({ editable, update, focus }), [editable, update, focus]);

  useEffect(() => {
    document.documentElement.classList.add("hydrated");
    setEditable(true);
  }, []);

  useLayoutEffect(() => {
    const root = measureRef.current;
    if (!root) return;
    const measuredPages = paginate(blocks, readMeasure(root), availableHeight(layout));
    if (!samePages(pagesRef.current, measuredPages)) {
      const active = document.activeElement as HTMLElement | null;
      if (active?.dataset?.fid && !pendingFocus.current) {
        pendingFocus.current = { id: active.dataset.fid, offset: getCaret(active), force: false, time: Date.now() };
      }
      setPages(measuredPages);
    }
  }, [blocks, layout]);

  useLayoutEffect(() => {
    const pending = pendingFocus.current;
    if (!pending) return;
    if (Date.now() - pending.time > 1500) {
      pendingFocus.current = null;
      return;
    }
    const element = document.querySelector<HTMLElement>(`.quotation-pages [data-fid="${CSS.escape(pending.id)}"]`);
    if (!element) return;
    pendingFocus.current = null;
    if (pending.force || document.activeElement !== element) setCaret(element, pending.offset);
  });

  const save = useCallback(async () => {
    const requestVersion = version.current;
    setStatus("saving");
    try {
      const response = await fetch(`/api/quotations/${activeIdRef.current}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ doc: docRef.current }),
      });
      if (!response.ok) throw new Error(String(response.status));
      savedVersion.current = Math.max(savedVersion.current, requestVersion);
      setStatus(savedVersion.current >= version.current ? "saved" : "dirty");
    } catch {
      setStatus("error");
    }
  }, []);

  useEffect(() => {
    if (firstDoc.current) {
      firstDoc.current = false;
      return;
    }
    version.current++;
    setStatus("dirty");
    window.clearTimeout(saveTimer.current);
    saveTimer.current = window.setTimeout(() => void save(), 600);
  }, [doc, save]);

  useEffect(() => {
    const beforeLeave = (event: BeforeUnloadEvent) => {
      if (savedVersion.current >= version.current) return;
      try {
        void fetch(`/api/quotations/${activeIdRef.current}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ doc: docRef.current }),
          keepalive: true,
        });
      } catch { /* best effort */ }
      event.preventDefault();
    };
    window.addEventListener("beforeunload", beforeLeave);
    return () => window.removeEventListener("beforeunload", beforeLeave);
  }, []);

  useEffect(() => {
    const elements = Array.from(document.querySelectorAll<HTMLElement>(".quotation-pages .q-page:not(.is-in)"));
    if (!("IntersectionObserver" in window)) {
      elements.forEach((element) => element.classList.add("is-in"));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-in");
          observer.unobserve(entry.target);
        }
      }
    }, { threshold: 0.04 });
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [pages.length]);

  const onLetterheadFile = async (file: File) => {
    const token = ++uploadToken.current;
    setUpload({ busy: true, progress: "Reading file…", error: "" });
    try {
      const result = await prepareLetterhead(file, (progress) => {
        if (uploadToken.current === token) setUpload({ busy: true, progress, error: "" });
      });
      if (uploadToken.current !== token) return;
      update((d) => {
        d.letterhead.pages = result.pages.slice(0, MAX_LETTERHEAD_PAGES);
        d.letterhead.enabled = true;
        d.letterhead.mode = result.isPdf && result.pages.length > 1 ? "per-page" : "repeat";
        d.letterhead.fit = "contain";
        d.letterhead.spacing = "letterhead";
      });
      setUpload({ busy: false, progress: "", error: "" });
    } catch (error) {
      if (uploadToken.current !== token) return;
      setUpload({ busy: false, progress: "", error: error instanceof Error ? error.message : "Could not read the letterhead file." });
    }
  };

  const onSave = () => {
    window.clearTimeout(saveTimer.current);
    void save();
  };

  const onPrint = () => {
    window.clearTimeout(saveTimer.current);
    if (status !== "saved") void save();
    (document.activeElement as HTMLElement | null)?.blur?.();
    document.querySelectorAll(".q-page").forEach((element) => element.classList.add("is-in"));
    window.print();
  };

  const onShare = async () => {
    setShareMessage("");
    void save();
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: doc.title || "Quotation", text: `${doc.title} · ${doc.quotationNo}`, url });
        setShareMessage("Quotation link shared");
      } else {
        await navigator.clipboard.writeText(url);
        setShareMessage("Editor link copied");
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      try {
        await navigator.clipboard.writeText(url);
        setShareMessage("Editor link copied");
      } catch {
        setShareMessage("Copy the address from your browser to share");
      }
    }
    window.setTimeout(() => setShareMessage(""), 3600);
  };

  const onReset = () => {
    if (window.confirm("Restore the original sample quotation and remove the uploaded letterhead?")) {
      window.clearTimeout(saveTimer.current);
      setDoc(cloneDefault());
      setUpload({ busy: false, progress: "", error: "" });
    }
  };

  const refreshQuotations = useCallback(async () => {
    try {
      const res = await fetch("/api/quotations");
      if (!res.ok) return;
      const data = await res.json();
      setQuotations(Array.isArray(data.quotations) ? (data.quotations as QuotationMeta[]) : []);
    } catch {
      /* list refresh is best-effort */
    }
  }, []);

  const loadQuotation = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/quotations/${id}`);
      if (!res.ok) return;
      const data = await res.json();
      skipNextSave.current = true;
      setDoc(data.doc as QuoteDoc);
      setActiveId(id);
      window.history.replaceState(null, "", `?q=${encodeURIComponent(id)}`);
    } catch {
      /* ignore */
    }
  }, []);

  const onSelectQuotation = useCallback(
    (id: string) => {
      if (id === activeIdRef.current) return;
      void (async () => {
        await save();
        await loadQuotation(id);
        await refreshQuotations();
      })();
    },
    [save, loadQuotation, refreshQuotations],
  );

  const onCreateQuotation = useCallback(
    async (copyFrom?: string) => {
      try {
        const res = await fetch("/api/quotations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(copyFrom ? { copyFrom } : {}),
        });
        const data = await res.json();
        if (!res.ok || !data.id) return;
        skipNextSave.current = true;
        setDoc(data.doc as QuoteDoc);
        setActiveId(data.id as string);
        window.history.replaceState(null, "", `?q=${encodeURIComponent(data.id as string)}`);
        await refreshQuotations();
      } catch {
        /* ignore */
      }
    },
    [refreshQuotations],
  );

  const onDeleteQuotation = useCallback(async () => {
    const id = activeIdRef.current;
    if (!window.confirm("Delete this quotation? This cannot be undone.")) return;
    try {
      await fetch(`/api/quotations/${id}`, { method: "DELETE" });
    } catch {
      /* ignore */
    }
    await refreshQuotations();
    try {
      const res = await fetch("/api/quotations");
      const data = await res.json();
      const list = (Array.isArray(data.quotations) ? data.quotations : []) as QuotationMeta[];
      if (list.length === 0) {
        await onCreateQuotation();
        return;
      }
      await loadQuotation(list[0].id);
      await refreshQuotations();
    } catch {
      /* ignore */
    }
  }, [refreshQuotations, loadQuotation, onCreateQuotation]);

  /* Deep link: open the quotation named in ?q=… */
  useEffect(() => {
    const wanted = new URLSearchParams(window.location.search).get("q");
    if (wanted && wanted !== initialState.activeId) void loadQuotation(wanted);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resetZoom = () => setPreviewZoom(1);

  return (
    <ApiContext.Provider value={api}>
      <main className="builder-layout">
        <StudioSidebar
          doc={doc}
          update={update}
          status={status}
          onSave={onSave}
          onPrint={onPrint}
          onShare={onShare}
          onReset={onReset}
          onLetterheadFile={onLetterheadFile}
          uploading={upload.busy}
          uploadProgress={upload.progress}
          uploadError={upload.error}
          shareMessage={shareMessage}
          quotations={quotations}
          activeId={activeId}
          onSelectQuotation={onSelectQuotation}
          onNewQuotation={() => void onCreateQuotation()}
          onDuplicateQuotation={() => void onCreateQuotation(activeIdRef.current)}
          onDeleteQuotation={onDeleteQuotation}
        />

        <section className="preview-stage" aria-label="Quotation preview">
          <header className="preview-topbar">
            <div className="preview-title"><span className="preview-title-icon"><Icon name="fit" /></span><span><strong>Live preview</strong><small>{pages.length} {pages.length === 1 ? "page" : "pages"} · A4 portrait</small></span></div>
            <div className="zoom-controls" aria-label="Preview zoom">
              <button type="button" title="Zoom out" aria-label="Zoom out" onClick={() => setPreviewZoom((zoom) => Math.max(0.55, +(zoom - 0.1).toFixed(2)))}><Icon name="zoom-out" /></button>
              <button type="button" className="zoom-readout" title="Reset zoom" onClick={resetZoom}>{Math.round(previewZoom * 100)}%</button>
              <button type="button" title="Zoom in" aria-label="Zoom in" onClick={() => setPreviewZoom((zoom) => Math.min(1.35, +(zoom + 0.1).toFixed(2)))}><Icon name="zoom-in" /></button>
              <span className="zoom-divider" />
              <button type="button" className="top-print" onClick={onPrint}><Icon name="print" /><span>PDF</span></button>
            </div>
          </header>

          <div className="preview-scroll">
            <div className="quotation-pages" style={{ "--preview-zoom": previewZoom } as CSSProperties}>
              {pages.map((pageBlocks, index) => (
                <Sheet key={index} doc={doc} page={index + 1} pageCount={pages.length}>
                  {pageBlocks.map((block) => <BlockView key={block.key} block={block} doc={doc} />)}
                </Sheet>
              ))}
            </div>
          </div>
          <div className="preview-tip"><span className="tip-dot" />Click text on the page to edit, or use the menu on the left.</div>
        </section>

        <div className="q-measure" ref={measureRef} aria-hidden="true">
          <MeasureContext.Provider value={true}>{blocks.map((block) => <BlockView key={block.key} block={block} doc={doc} measure />)}</MeasureContext.Provider>
        </div>
      </main>
    </ApiContext.Provider>
  );
}
