"use client";

export const MAX_LETTERHEAD_PAGES = 8;
export const MAX_LETTERHEAD_FILE_BYTES = 32 * 1024 * 1024;
const MAX_PAGE_AREA = 1600 * 2260;
const MAX_PAGE_CHARS = 1_350_000;

type StoredPage = { src: string; stored: "s3" | "local" };

async function shrinkCanvas(source: HTMLCanvasElement): Promise<HTMLCanvasElement> {
  let canvas = source;
  for (let pass = 0; pass < 4; pass++) {
    if (canvas.width * canvas.height <= MAX_PAGE_AREA && canvas.width <= 1600 && canvas.height <= 2260) return canvas;
    const next = document.createElement("canvas");
    next.width = Math.max(480, Math.round(canvas.width * 0.78));
    next.height = Math.max(680, Math.round(canvas.height * 0.78));
    const ctx = next.getContext("2d");
    if (!ctx) throw new Error("Could not process the letterhead image.");
    ctx.drawImage(canvas, 0, 0, next.width, next.height);
    canvas = next;
  }
  return canvas;
}

function canvasToWebpBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Could not encode the letterhead page."))),
      "image/webp",
      quality,
    );
  });
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read the letterhead page."));
    reader.readAsDataURL(blob);
  });
}

async function uploadPage(blob: Blob, filename: string): Promise<string> {
  const form = new FormData();
  form.append("file", blob, filename);
  const res = await fetch("/api/letterhead", { method: "POST", body: form });
  if (!res.ok) {
    if (res.status === 503) return ""; // cloud storage not configured — caller stores locally
    throw new Error("Letterhead upload failed. Please try again.");
  }
  const json = await res.json();
  if (!json || typeof json.url !== "string" || !json.url.startsWith("/api/letterhead/")) {
    throw new Error("Letterhead upload failed. Please try again.");
  }
  return json.url as string;
}

/** Encode one page, prefer S3, fall back to an in-document data URI. */
async function storePage(canvas: HTMLCanvasElement, filename: string): Promise<StoredPage> {
  for (const quality of [0.88, 0.78, 0.68, 0.58]) {
    const shrunk = await shrinkCanvas(canvas);
    const blob = await canvasToWebpBlob(shrunk, quality);
    if (blob.size > 1_400_000) continue; // try a lower quality pass
    const url = await uploadPage(blob, filename);
    if (url) return { src: url, stored: "s3" };
    if (blob.size <= MAX_PAGE_CHARS * 0.75) {
      const dataUrl = await blobToDataUrl(blob);
      if (dataUrl.length <= MAX_PAGE_CHARS) return { src: dataUrl, stored: "local" };
    }
  }
  throw new Error("This page is too detailed to save. Try a simpler letterhead or lower-resolution PDF.");
}

async function imageFileToPage(file: File): Promise<StoredPage> {
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error("This image could not be opened. Use a PNG, JPG, or WebP image.");
  }
  const ratio = Math.min(1, 1600 / bitmap.width, 2260 / bitmap.height);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * ratio));
  canvas.height = Math.max(1, Math.round(bitmap.height * ratio));
  const context = canvas.getContext("2d");
  if (!context) {
    bitmap.close();
    throw new Error("Could not process the letterhead image.");
  }
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return storePage(canvas, file.name.replace(/\.[^.]+$/, "") || "letterhead");
}

async function pdfToPages(file: File, onProgress: (text: string) => void): Promise<StoredPage[]> {
  try {
    const pdfjs = await import("pdfjs-dist");
    pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
    const loadingTask = pdfjs.getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
      useSystemFonts: true,
    });
    const pdf = await loadingTask.promise;

    const count = Math.min(pdf.numPages, MAX_LETTERHEAD_PAGES);
    const pages: StoredPage[] = [];
    let total = 0;

    for (let n = 1; n <= count; n++) {
      onProgress(`Preparing page ${n} of ${count}…`);
      const page = await pdf.getPage(n);
      const base = page.getViewport({ scale: 1 });
      const scale = Math.min(1600 / base.width, 2260 / base.height, 2.6);
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.floor(viewport.width));
      canvas.height = Math.max(1, Math.floor(viewport.height));
      const context = canvas.getContext("2d", { alpha: false });
      if (!context) throw new Error("Could not render this PDF.");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvas, canvasContext: context, viewport, background: "#ffffff" }).promise;
      const stored = await storePage(canvas, `letterhead-page-${n}`);
      if (total + stored.src.length > 6_600_000 && stored.stored === "local") {
        throw new Error("This PDF is too large after conversion. Try a PDF with fewer or simpler pages.");
      }
      pages.push(stored);
      total += stored.src.length;
      canvas.width = 1;
      canvas.height = 1;
      page.cleanup();
    }

    if (pdf.numPages > MAX_LETTERHEAD_PAGES) {
      onProgress(`First ${MAX_LETTERHEAD_PAGES} of ${pdf.numPages} pages prepared.`);
    }
    await pdf.cleanup();
    await loadingTask.destroy();
    return pages;
  } catch (error) {
    if (error instanceof Error && (error.message.startsWith("This PDF") || error.message.startsWith("Could not"))) throw error;
    throw new Error("This PDF could not be opened. Try a standard, unlocked PDF file.");
  }
}

export async function prepareLetterhead(
  file: File,
  onProgress: (text: string) => void,
): Promise<{ pages: string[]; isPdf: boolean; stored: "s3" | "local" }> {
  if (file.size > MAX_LETTERHEAD_FILE_BYTES) throw new Error("Please choose a file smaller than 32 MB.");
  const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
  if (isPdf) {
    const storedPages = await pdfToPages(file, onProgress);
    return {
      pages: storedPages.map((p) => p.src),
      isPdf: true,
      stored: storedPages.every((p) => p.stored === "s3") ? "s3" : "local",
    };
  }
  const page = await imageFileToPage(file);
  return { pages: [page.src], isPdf: false, stored: page.stored };
}
