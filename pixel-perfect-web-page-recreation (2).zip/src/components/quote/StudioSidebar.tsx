"use client";

import { useRef, useState, type ChangeEvent, type DragEvent, type ReactNode } from "react";
import { uid, type Letterhead, type QuotationMeta, type QuoteDoc } from "@/lib/quote";

export type SaveStatus = "saved" | "dirty" | "saving" | "error";

export type StudioSidebarProps = {
  doc: QuoteDoc;
  update: (fn: (d: QuoteDoc) => void) => void;
  status: SaveStatus;
  onSave: () => void;
  onPrint: () => void;
  onShare: () => void;
  onReset: () => void;
  onLetterheadFile: (file: File) => void;
  uploading: boolean;
  uploadProgress: string;
  uploadError: string;
  shareMessage: string;
  quotations: QuotationMeta[];
  activeId: string;
  onSelectQuotation: (id: string) => void;
  onNewQuotation: () => void;
  onDuplicateQuotation: () => void;
  onDeleteQuotation: () => void;
};

type SectionId = "letterhead" | "details" | "items" | "terms" | "signature";

function Glyph({ name, size = 16 }: { name: string; size?: number }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const paths: Record<string, ReactNode> = {
    paper: <><path d="M7 3h7l4 4v14H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></>,
    letter: <><path d="M4 4h16v16H4z"/><path d="M4 9h16M9 4v5m6-5v5M8 14h2m4 0h2m-8 3h2m4 0h2"/></>,
    edit: <><path d="m15 5 4 4M4 20l4-.8L19.2 8a2.1 2.1 0 0 0-3-3L5 16.2 4 20Z"/><path d="M12 20h8"/></>,
    rows: <><path d="M4 5h16M4 10h16M4 15h10M4 20h10"/><path d="M18 15v6m-3-3h6"/></>,
    terms: <><path d="M8 5h12M8 10h12M8 15h12M8 20h12"/><path d="M4 5h.01M4 10h.01M4 15h.01M4 20h.01"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    save: <><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/></>,
    print: <><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></>,
    share: <><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.6 6.6-3.2m-6.6 6 6.6 3.2"/></>,
    reset: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></>,
    upload: <><path d="M12 16V4m-4 4 4-4 4 4"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/></>,
    trash: <><path d="M4 7h16M10 11v6m4-6v6M5 7l1 14h12l1-14M9 7V4h6v3"/></>,
    plus: <><path d="M12 5v14m-7-7h14"/></>,
    chevron: <path d="m7 10 5 5 5-5"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    close: <><path d="M6 6l12 12M18 6 6 18"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/></>,
    page: <><path d="M6 3h9l4 4v14H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" {...common}>{paths[name] ?? paths.info}</svg>;
}

function Input({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  min,
  max,
  step,
}: {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  min?: number;
  max?: number;
  step?: number;
}) {
  return (
    <label className="studio-field">
      <span>{label}</span>
      <input type={type} value={value} min={min} max={max} step={step} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function Textarea({
  label,
  value,
  onChange,
  placeholder,
  rows = 2,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <label className="studio-field">
      <span>{label}</span>
      <textarea rows={rows} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}

function SectionCard({
  id,
  title,
  subtitle,
  icon,
  open,
  onToggle,
  children,
}: {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  return (
    <section className={`studio-card${open ? " is-open" : ""}`} id={`studio-${id}`}>
      <button className="studio-card-head" type="button" aria-expanded={open} onClick={onToggle}>
        <span className="studio-card-icon"><Glyph name={icon} /></span>
        <span className="studio-card-heading">
          <strong>{title}</strong>
          <small>{subtitle}</small>
        </span>
        <span className={`studio-chevron${open ? " turned" : ""}`}><Glyph name="chevron" size={15} /></span>
      </button>
      {open && <div className="studio-card-body">{children}</div>}
    </section>
  );
}

function SectionNav({ onGo }: { onGo: (id: SectionId) => void }) {
  const links: { id: SectionId; label: string; icon: string }[] = [
    { id: "letterhead", label: "Letterhead", icon: "letter" },
    { id: "details", label: "Details", icon: "edit" },
    { id: "items", label: "Items", icon: "rows" },
    { id: "terms", label: "Terms", icon: "terms" },
    { id: "signature", label: "Sign-off", icon: "user" },
  ];
  return (
    <nav className="studio-nav" aria-label="Quotation sections">
      {links.map((link) => (
        <button key={link.id} type="button" onClick={() => onGo(link.id)}>
          <Glyph name={link.icon} size={14} /><span>{link.label}</span>
        </button>
      ))}
    </nav>
  );
}

export default function StudioSidebar({
  doc,
  update,
  status,
  onSave,
  onPrint,
  onShare,
  onReset,
  onLetterheadFile,
  uploading,
  uploadProgress,
  uploadError,
  shareMessage,
  quotations,
  activeId,
  onSelectQuotation,
  onNewQuotation,
  onDuplicateQuotation,
  onDeleteQuotation,
}: StudioSidebarProps) {
  const uploadRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [open, setOpen] = useState<Set<SectionId>>(() => new Set(["letterhead", "details"]));
  const [mobileOpen, setMobileOpen] = useState(true);

  const toggleSection = (id: SectionId) => {
    setOpen((old) => {
      const next = new Set(old);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const goTo = (id: SectionId) => {
    setMobileOpen(true);
    setOpen((old) => new Set(old).add(id));
    window.setTimeout(() => {
      document.getElementById(`studio-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 70);
  };

  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (file) onLetterheadFile(file);
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    const file = event.dataTransfer.files?.[0];
    if (file) onLetterheadFile(file);
  };

  const changeLetterhead = (fn: (value: Letterhead) => Letterhead) =>
    update((d) => {
      d.letterhead = fn(d.letterhead);
    });

  const setInfo = (i: number, key: "label" | "value", value: string) =>
    update((d) => {
      d.info[i][key] = value;
    });

  const setBoq = (i: number, key: "discipline" | "category" | "note" | "qty" | "unit" | "rate", value: string) =>
    update((d) => {
      d.boq[i][key] = value;
    });

  const setSection = (i: number, key: "num" | "title", value: string) =>
    update((d) => {
      d.sections[i][key] = value;
    });

  const statusLabel = status === "saved" ? "Saved" : status === "saving" ? "Saving…" : status === "dirty" ? "Unsaved changes" : "Save failed";

  return (
    <aside className={`studio-sidebar${mobileOpen ? " mobile-open" : " mobile-closed"}`} aria-label="Quotation editor">
      <header className="studio-top">
        <div className="studio-brand">
          <span className="studio-brand-mark"><Glyph name="paper" size={20} /></span>
          <span><strong>Quotation</strong><small>Document studio</small></span>
        </div>
        <button className="studio-mobile-toggle" type="button" onClick={() => setMobileOpen((v) => !v)} aria-expanded={mobileOpen}>
          {mobileOpen ? "Hide editor" : "Edit quotation"}<Glyph name="chevron" size={15} />
        </button>
        <SectionNav onGo={goTo} />
      </header>

      <div className="studio-content">
        <section className="studio-card is-open" id="studio-quotations">
          <div className="studio-card-head">
            <span className="studio-card-icon"><Glyph name="paper" /></span>
            <span className="studio-card-heading">
              <strong>Quotations</strong>
              <small>{quotations.length} saved · shared on this link</small>
            </span>
          </div>
          <div className="studio-card-body">
            <label className="studio-field">
              <span>Active quotation</span>
              <select value={activeId} onChange={(e) => onSelectQuotation(e.target.value)}>
                {quotations.map((q) => (
                  <option key={q.id} value={q.id}>
                    {q.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="quotation-actions">
              <button type="button" onClick={onNewQuotation}>New</button>
              <button type="button" onClick={onDuplicateQuotation}>Duplicate</button>
              <button type="button" className="danger" onClick={onDeleteQuotation}>Delete</button>
            </div>
            <p className="studio-hint">Saved on the server — everyone with this link sees the same list. Use <b>Download PDF</b> to send one to a client.</p>
          </div>
        </section>
        <SectionCard id="letterhead" title="Your letterhead" subtitle="Upload once · repeat on every sheet" icon="letter" open={open.has("letterhead")} onToggle={() => toggleSection("letterhead")}>
          <input ref={uploadRef} className="studio-hidden-file" type="file" accept=".pdf,application/pdf,image/png,image/jpeg,image/webp,image/avif" onChange={onFileChange} />
          <div
            className={`letter-drop${dragging ? " is-dragging" : ""}${doc.letterhead.pages.length ? " has-preview" : ""}`}
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
            onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDragging(false); }}
            onDrop={onDrop}
          >
            <span className="drop-icon"><Glyph name={uploading ? "page" : "upload"} size={21} /></span>
            <strong>{uploading ? uploadProgress || "Preparing letterhead…" : doc.letterhead.pages.length ? `${doc.letterhead.pages.length} ${doc.letterhead.pages.length === 1 ? "page" : "pages"} ready` : "Drop your letterhead here"}</strong>
            <span>{uploading ? "This may take a moment" : "A full-page PDF, PNG, JPG or WebP"}</span>
            {!uploading && (
              <button type="button" className="browse-button" onClick={() => uploadRef.current?.click()}>
                <Glyph name="upload" size={14} /> {doc.letterhead.pages.length ? "Replace file" : "Choose file"}
              </button>
            )}
          </div>
          {uploadError && <p className="studio-error" role="alert">{uploadError}</p>}
          {uploading && <div className="upload-progress" role="progressbar"><span /></div>}
          {doc.letterhead.pages.length > 0 ? (
            <>
              <div className="letter-previews" aria-label="Uploaded letterhead pages">
                {doc.letterhead.pages.map((src, index) => (
                  <div className="letter-preview-wrap" key={index}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img className="letter-preview" src={src} alt={`Letterhead page ${index + 1}`} />
                    <span>Page {index + 1}</span>
                  </div>
                ))}
              </div>
              {doc.letterhead.pages.length > 1 && (
                <div className="studio-option-row">
                  <span>Apply PDF pages</span>
                  <select value={doc.letterhead.mode} onChange={(e) => changeLetterhead((lh) => ({ ...lh, mode: e.target.value === "per-page" ? "per-page" : "repeat" }))}>
                    <option value="per-page">Match each quotation page</option>
                    <option value="repeat">Repeat the first page</option>
                  </select>
                </div>
              )}
              <div className="studio-option-row">
                <span>Page image</span>
                <select value={doc.letterhead.fit} onChange={(e) => changeLetterhead((lh) => ({ ...lh, fit: e.target.value === "cover" ? "cover" : "contain" }))}>
                  <option value="contain">Fit whole page · no crop</option>
                  <option value="cover">Fill page · crop edges</option>
                </select>
              </div>
              <div className="studio-option-row">
                <span>Content position</span>
                <select value={doc.letterhead.spacing} onChange={(e) => changeLetterhead((lh) => ({ ...lh, spacing: e.target.value === "letterhead" ? "letterhead" : "compact" }))}>
                  <option value="letterhead">Leave space for header</option>
                  <option value="compact">Compact · start near top</option>
                </select>
              </div>
              <div className="letterhead-actions">
                <label className="studio-check">
                  <input type="checkbox" checked={doc.letterhead.enabled} onChange={(e) => changeLetterhead((lh) => ({ ...lh, enabled: e.target.checked }))} />
                  <span>Show on quotation pages</span>
                </label>
                <button className="icon-button danger" type="button" title="Remove letterhead" aria-label="Remove letterhead" onClick={() => changeLetterhead((lh) => ({ ...lh, pages: [], enabled: false, mode: "repeat", spacing: "compact" }))}>
                  <Glyph name="trash" size={15} />
                </button>
              </div>
              <p className="studio-hint">Each uploaded page becomes the complete page background. A one-page image repeats; multi-page PDFs can use a different background on each sheet.</p>
            </>
          ) : (
            <p className="studio-hint">Upload a complete A4 letterhead PDF or full-page image. Without an upload, the quotation prints on clean white pages.</p>
          )}
        </SectionCard>

        <SectionCard id="details" title="Quotation details" subtitle="Date · number · recipient" icon="edit" open={open.has("details")} onToggle={() => toggleSection("details")}>
          <div className="studio-grid two">
            <Input label="Date" value={doc.date} placeholder="e.g. 15 November 2026" onChange={(v) => update((d) => { d.date = v; })} />
            <Input label="Revision" value={doc.rev} onChange={(v) => update((d) => { d.rev = v; })} />
          </div>
          <Input label="Quotation number" value={doc.quotationNo} placeholder="QTN-000-00" onChange={(v) => update((d) => { d.quotationNo = v; })} />
          <Input label="Document title" value={doc.title} onChange={(v) => update((d) => { d.title = v; })} />
          <div className="studio-list-heading"><strong>Recipient & project</strong><span>{doc.info.length} fields</span></div>
          {doc.info.map((row, i) => (
            <div className="recipient-row" key={row.id}>
              <div className="studio-grid two">
                <Input label="Field label" value={row.label} onChange={(v) => setInfo(i, "label", v)} />
                <Input label="Value" value={row.value} placeholder="Type here" onChange={(v) => setInfo(i, "value", v)} />
              </div>
              <button className="inline-remove" type="button" onClick={() => update((d) => { d.info.splice(i, 1); })} aria-label={`Remove ${row.label || "recipient"} field`}>
                <Glyph name="trash" size={13} /><span>Remove field</span>
              </button>
            </div>
          ))}
          <button className="add-control" type="button" onClick={() => update((d) => { d.info.push({ id: uid("i"), label: "", value: "" }); })}>
            <Glyph name="plus" size={15} /> Add recipient field
          </button>
        </SectionCard>

        <SectionCard id="items" title="Bill of quantities" subtitle={`${doc.boq.length} line items · unit rates in SAR`} icon="rows" open={open.has("items")} onToggle={() => toggleSection("items")}>
          {doc.boq.map((row, i) => (
            <div className="item-card" key={row.id}>
              <div className="item-card-title"><strong>Item {String(i + 1).padStart(2, "0")}</strong><button className="icon-button danger" type="button" aria-label={`Delete item ${i + 1}`} title="Delete item" onClick={() => update((d) => { const wasMerged = d.boq[i].merge; const group = d.boq[i].discipline; d.boq.splice(i, 1); if (d.boq[0]) d.boq[0].merge = false; if (wasMerged && i > 0 && i < d.boq.length && d.boq[i].merge) { d.boq[i].merge = false; d.boq[i].discipline = group; } })}><Glyph name="trash" size={14} /></button></div>
              <Input label="Discipline" value={row.discipline} placeholder="e.g. HSE" onChange={(v) => setBoq(i, "discipline", v)} />
              <Input label="Personnel category" value={row.category} placeholder="Role / service" onChange={(v) => setBoq(i, "category", v)} />
              <div className="studio-grid two">
                <Input label="Note" value={row.note} placeholder="Optional qualification" onChange={(v) => setBoq(i, "note", v)} />
                <Input label="Quantity" value={row.qty} placeholder="1" onChange={(v) => setBoq(i, "qty", v)} />
              </div>
              <div className="studio-grid two">
                <Input label="Unit" value={row.unit} placeholder="Man-hour" onChange={(v) => setBoq(i, "unit", v)} />
                <Input label="Unit rate (SAR)" value={row.rate} placeholder="0.00" onChange={(v) => setBoq(i, "rate", v)} />
              </div>
            </div>
          ))}
          <button className="add-control" type="button" onClick={() => update((d) => { d.boq.push({ id: uid("r"), discipline: "", merge: false, category: "", note: "", qty: "1", unit: "Man-hour", rate: "" }); })}>
            <Glyph name="plus" size={15} /> Add line item
          </button>
        </SectionCard>

        <SectionCard id="terms" title="Terms & conditions" subtitle="Sections · payment · validity" icon="terms" open={open.has("terms")} onToggle={() => toggleSection("terms")}>
          <Input label="Section heading" value={doc.termsTitle} onChange={(v) => update((d) => { d.termsTitle = v; })} />
          {doc.sections.map((section, si) => (
            <div className="terms-card" key={section.id}>
              <div className="studio-grid two">
                <Input label="Number" value={section.num} onChange={(v) => setSection(si, "num", v)} />
                <Input label="Section title" value={section.title} onChange={(v) => setSection(si, "title", v)} />
              </div>
              {section.bullets.map((bullet, bi) => (
                <div className="bullet-editor" key={bullet.id}>
                  <Textarea label={`Condition ${bi + 1}`} value={bullet.text} placeholder="Write a condition" rows={2} onChange={(v) => update((d) => { d.sections[si].bullets[bi].text = v; })} />
                  <button className="icon-button danger bullet-remove" type="button" title="Remove condition" aria-label="Remove condition" onClick={() => update((d) => { d.sections[si].bullets.splice(bi, 1); })}><Glyph name="trash" size={14} /></button>
                </div>
              ))}
              <button className="add-control smaller" type="button" onClick={() => update((d) => { d.sections[si].bullets.push({ id: uid("b"), text: "" }); })}>
                <Glyph name="plus" size={14} /> Add condition
              </button>
              <button className="inline-remove section-remove" type="button" onClick={() => update((d) => { d.sections.splice(si, 1); })}><Glyph name="trash" size={13} /><span>Remove section</span></button>
            </div>
          ))}
          <button className="add-control" type="button" onClick={() => update((d) => { d.sections.push({ id: uid("s"), num: `${d.sections.length + 1}.`, title: "New condition", style: "deep", gap: 18, bullets: [] }); })}>
            <Glyph name="plus" size={15} /> Add terms section
          </button>
        </SectionCard>

        <SectionCard id="signature" title="Closing & sign-off" subtitle="Message · contact · signature" icon="user" open={open.has("signature")} onToggle={() => toggleSection("signature")}>
          <Textarea label="Closing message" value={doc.closing} rows={3} onChange={(v) => update((d) => { d.closing = v; })} />
          <Input label="Sign-off" value={doc.regards} onChange={(v) => update((d) => { d.regards = v; })} />
          <Input label="Name" value={doc.signer.name} onChange={(v) => update((d) => { d.signer.name = v; })} />
          <Input label="Position / title" value={doc.signer.title} onChange={(v) => update((d) => { d.signer.title = v; })} />
          <Input label="Mobile" value={doc.signer.mobile} onChange={(v) => update((d) => { d.signer.mobile = v; })} />
          <Input label="Email" type="email" value={doc.signer.email} onChange={(v) => update((d) => { d.signer.email = v; })} />
          <Input label="Company" value={doc.signer.company} onChange={(v) => update((d) => { d.signer.company = v; })} />
        </SectionCard>
      </div>

      <footer className="studio-actions">
        <div className="studio-save-state" aria-live="polite">
          <span className={`status-dot ${status}`} />
          <span>{statusLabel}</span>
        </div>
        <div className="studio-action-grid">
          <button className="action-button primary" type="button" onClick={onPrint}><Glyph name="print" size={16} /> Download PDF</button>
          <button className="action-button" type="button" onClick={onShare}><Glyph name="share" size={15} /> Share / copy link</button>
          <button className="action-button quiet" type="button" onClick={onSave}><Glyph name="save" size={15} /> Save now</button>
          <button className="action-button quiet reset-action" type="button" onClick={onReset}><Glyph name="reset" size={15} /> Reset draft</button>
        </div>
        {shareMessage && <p className="share-feedback" role="status"><Glyph name="check" size={13} />{shareMessage}</p>}
        <div className="studio-footnote"><span>Auto-save is on</span><span>·</span><span>Ctrl/Cmd + P to print</span></div>
      </footer>
    </aside>
  );
}
